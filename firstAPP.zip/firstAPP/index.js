// import 
const express = require("express");


const app = express();

const PORT = 4000;


app.use(express.json());

// middlewares function 
// app.use(function (request, response, next) {
//     // response.send(`
//     //     <h1>First Post</h1>
//     //     <p>this is first post</p>
//     // `);x
//     console.log("Hello Wolrd")
//     next();
// })



app.use("/display", function (request, response) {
    console.log(request.body)
    response.send(request.body)
})



app.listen(PORT, () => {
    console.log("Server is running at port no", PORT);
})

// npm init 
// npm install --save express
// npm install nodemon